def calculate_complexity(model):
    total_params = sum(p.numel() for p in model.parameters())  # 计算总参数数量
    total_layers = len([layer for layer in model.modules() if isinstance(layer, nn.Conv2d) or isinstance(layer, nn.Linear)])  # 计算总层数
    total_nodes = sum(layer.out_features if hasattr(layer, 'out_features') else layer.out_channels for layer in model.modules() if isinstance(layer, nn.Linear) or isinstance(layer, nn.Conv2d))  # 计算总节点数量

    return total_params, total_layers, total_nodes

# 创建一个网络实例
model = Net()
total_params, total_layers, total_nodes = calculate_complexity(model)
print("Total Parameters:", total_params)
print("Total Layers:", total_layers)
print("Total Nodes:", total_nodes)
