在深度学习中，归一化（Normalization）通常指的是批归一化（Batch Normalization），它是一种用于加速深度神经网络训练的技术。在给定一个输入的情况下，批归一化通过对每一层的输入进行标准化处理，即使得每个特征的均值接近于0，标准差接近于1。这样做的好处有几个：

1. **加速收敛速度**：批归一化有助于防止梯度消失或梯度爆炸，使得网络能够更快地收敛。

2. **降低对初始权重的敏感性**：归一化可以降低对网络参数初始值的敏感性，减少了训练的不稳定性。

3. **正则化效果**：批归一化在一定程度上具有正则化的效果，有助于减少过拟合。

在给定的网络结构中，批归一化层（`nn.BatchNorm2d`）被插入到卷积层或全连接层之后，激活函数之前。这样做使得每一层的输入在传递给激活函数之前都会被归一化，从而增强了网络的稳定性和训练效果。

对比不使用归一化的情况，网络可能更容易受到梯度消失或爆炸的影响，训练过程可能更加不稳定，需要更小的学习率和更谨慎的参数初始化来避免这些问题。



## 代码：

    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, 3, 1)

        self.bn1 = nn.BatchNorm2d(32)#批归一化

        self.conv2 = nn.Conv2d(32, 64, 3, 1)

        self.bn2 = nn.BatchNorm2d(64)#批归一化

        self.dropout1 = nn.Dropout(0.25)
        self.dropout2 = nn.Dropout(0.5)
        self.fc1 = nn.Linear(9216, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.conv1(x)

        x = self.bn1(x)  #在激活函数前进行归一化

        x = F.relu(x)
        x = self.conv2(x)

        x = self.bn2(x)   #在激活函数前进行归一化
        
        x = F.relu(x)
        x = F.max_pool2d(x, 2)
        x = self.dropout1(x)
        x = torch.flatten(x, 1)
        x = self.fc1(x)
        x = F.relu(x)
        x = self.dropout2(x)
        x = self.fc2(x)
        output = F.log_softmax(x, dim=1)
        return output