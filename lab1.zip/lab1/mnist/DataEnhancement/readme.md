添加随机水平翻转（`RandomHorizontalFlip`）和随机旋转（`RandomRotation`）的主要区别在于数据增强的方式。数据增强是指通过对训练数据进行一系列随机变换来增加数据的多样性，从而提高模型的泛化能力。

1. **随机水平翻转**：
   - 添加随机水平翻转会在训练过程中随机地以50%的概率对图像进行水平翻转。这样做可以增加数据的多样性，帮助模型学习到物体在图像中不同的方向上的表现，从而提高模型的鲁棒性。

2. **随机旋转**：
   - 添加随机旋转会在训练过程中随机地对图像进行一定角度范围内的旋转。在这个例子中，旋转角度范围是在-10度到+10度之间。旋转可以模拟现实世界中物体的不同角度和姿态，从而使模型更好地适应不同角度的物体。

区别：
- 添加了随机水平翻转和随机旋转可以增加训练数据的多样性，使得模型更加健壮，能够处理更多不同角度和方向的物体。
- 不添加这些数据增强方式可能会导致模型对于训练集中的特定方向和角度过度拟合，从而降低了模型的泛化能力。



代码：


from torchvision import transforms
transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),  # 随机水平翻转
    transforms.RandomRotation(10),  # 在（-10，+10）范围内随机旋转
    transforms.ToTensor(),  # 转为Tensor
])


4.csv
transform=transforms.Compose([
   transforms.RandomHorizontalFlip(),  # 随机水平翻转
   transforms.RandomRotation(10),      # 在（-10，+10）范围内随机旋转
   transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),  # 随机颜色抖动
   transforms.RandomResizedCrop(28, scale=(0.8, 1.0), ratio=(0.9, 1.1)),  # 随机裁剪和缩放
   transforms.ToTensor(),
   transforms.Normalize((0.1307,), (0.3081,))
   ])