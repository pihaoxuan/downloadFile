import csv
import os
import matplotlib.pyplot as plt

# 读取多个CSV文件并绘制折线图
def plot_multiple_files(file_paths):
    for file_path in file_paths:
        file_name = os.path.splitext(os.path.basename(file_path))[0]  # 获取文件名（不含扩展名）
        epochs = []
        accuracies = []

        with open(file_path, newline='') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)  # 跳过标题行
            for row in reader:
                epoch = len(epochs) + 1  # 轮次从1开始
                accuracy = float(row[3])  # 获取精度
                epochs.append(epoch)
                accuracies.append(accuracy)

        # 使用不同颜色绘制每个文件的折线图，并添加图例
        plt.plot(epochs, accuracies, marker='o', label=file_name)

    plt.xlabel('Epoch')
    plt.ylabel('Accuracy (%)')
    plt.title('Accuracy over epochs')
    plt.grid(True)
    plt.xticks(range(1, max(epochs) + 1))  # 设置轮次的步长为1
    plt.yticks([i / 10 for i in range(int(min(accuracies) * 10), int(max(accuracies) * 10) + 1)])  # 设置纵坐标刻度更详细
    plt.legend()  # 添加图例
    plt.savefig("./DataEnhancement/all.png")

# 多个文件路径
# file_paths = ['./change_optimizer_weight/no_weight_decay.csv',  './DataEnhancement/flipAndRotation20.csv', './DataEnhancement/flipAndRotation10.csv']  # 替换为你的CSV文件路径
# file_paths = ['./change_optimizer_weight/no_weight_decay.csv', './DataEnhancement/RandomHorizontalFlip.csv','./DataEnhancement/Rotation10.csv']  # 替换为你的CSV文件路径
file_paths = ['./change_optimizer_weight/no_weight_decay.csv', './DataEnhancement/all.csv']  # 替换为你的CSV文件路径
plot_multiple_files(file_paths)
